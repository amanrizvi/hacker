import React from 'react';
import './App.css';


import Routes from './routes';
// import Comments from './Comments';
import NavBar from './NavBar';

function App() {
  return (
    
    <div className='myApp'>
      <NavBar />
      <Routes />
    </div>
    
  );
}

export default App;
