import React from 'react';
import {Row, Col, Container, Table, Button, ButtonGroup} from 'reactstrap';
import {GrUpdate} from 'react-icons/gr';
import {BiCommentCheck} from 'react-icons/bi'

class Comments extends React.Component {
    constructor(props) { 
        super(props);
        this.state = {
            id: props.location.aboutProps, 
            data: [],
            comment: '', 
            results: [], 
            updateTitle: '', 
            updatedUrl: '', 
            updatedText: ''
        };
        console.log(this.state.id);
        this.handleone = this.handleone.bind(this);
        this.handletwo = this.handletwo.bind(this);
        this.updatePost = this.updatePost.bind(this);
        this.sendNewPost = this.sendNewPost.bind(this);
        this.hideUpdate = this.hideUpdate.bind(this);
        this.one = this.one.bind(this); 
        this.two = this.two.bind(this);
        this.three = this.three.bind(this);
        this.four = this.four.bind(this);
    }

    async componentWillMount() { 
        console.log(this.state.id);
        const Options = { 
            method: 'POST', 
            headers: { 
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: this.state.id
              }),
            json: true
        }
        const save = await fetch('/getPost', Options);
        const results = await save.json();
        this.setState({ 
            results: results,
            // comment: results.res.comment,
            // updateTitle: results.res.title,
            // updatedText: results.res.txt_body,

        });
        console.log(results);
    };

    async handleone() { 
        console.log(this.state.comment);
        const Options = { 
            method: 'POST', 
            headers: { 
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: this.state.id,
                comment: this.state.comment
              }),
            json: true
        }
        const save = await fetch('/addComment', Options);
        const results = await save.json(); 
        console.log(results);
            //return console.log("Im in handleClick");
            //get endpoint here to post to mongodb
            //send a json of everything in the text field title and url
    };

    //will delete post
    async handletwo() { 
        console.log(this.state.comment);
        const Options = { 
            method: 'POST', 
            headers: { 
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: this.state.id
              }),
            json: true
        }
        const save = await fetch('/deleteList', Options);
        const results = await save.json(); 
        console.log(results);
    };

    hideUpdate() { 
        document.getElementById("updated_components").style.display = "none";
    };

    updatePost() { 
        document.getElementById("updated_components").style.display = "inline";
    };

    async sendNewPost() { 
        console.log(this.state.comment);
        const Options = { 
            method: 'POST', 
            headers: { 
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: this.state.id, 
                new_title: this.state.updatedTitle,
                new_url: this.state.updatedURL, 
                new_text: this.state.updatedText
              }),
            json: true
        };
        const save = await fetch('/updatePost', Options);
        const results = await save.json(); 
        console.log(results);
    };

    one(e) { 
        this.setState({
            comment: e.target.value
        });
    };
    two(e) { 
        this.setState({
            updatedTitle: e.target.value
        });
    };
    three(e) { 
        this.setState({
            updatedURL: e.target.value
        });
    };
    four(e) { 
        this.setState({
            updatedText: e.target.value
        });
    };


    render() {
        const list = this.state.comment;
        return (
            <div style={{fontSize: '20px'}}>
                <Container>   
                {/* <div style={{textAlign: 'center'}}>
                        <strong><h1>{this.state.updateTitle}</h1></strong>
                        <h3>{this.state.updatedText}</h3>
                    </div> 
                    {/* <h4>Comments:</h4>  */}
                    {/* <div>
                        {list.map((item) => 
                        <div key={list.indexOf(item)}>{item}  </div> )}
                    </div>   */}

            <Row>
               <Col>
               <p style={{marginTop: '270px', marginLeft: '200px'}}> 
                Comment Here:
                </p>
               </Col>
               <Col>
               <input type="text"  onChange={this.one} style={{marginTop: '270px', width: '300px', marginLeft: '-70px'}} ></input>  
               </Col>
           </Row>
           <ButtonGroup>
                <Button color="secondary"  onClick={ () => this.handleone()} variant="primary" style={{ marginLeft: '470px', marginTop: '20px'}}> <BiCommentCheck /> Comment</Button>
                <Button color="danger"  onClick={ () => this.handletwo()} variant="primary" style={{ marginTop: '20px'}}> Delete Post </Button>
                <Button color="warning"  onClick={ () => this.updatePost()} variant="primary" style={{ marginTop: '20px'}}> Update Post</Button>
            </ButtonGroup>
            <br /> <br />
                    <div id="updated_components" style={{display:"none"}}> 
                    <Row>
                        <Col md={3}>
                        <p> Updated Title:</p>
                        </Col>
                        <Col>
                        <input type="text" style={{ position: 'absolute', 
                    width:"500px", height:"25px"}} onChange={this.two}></input> 
                        </Col>
                    </Row>
                    <Row>
                        <Col md={3}>
                            <p>Updated Url:</p>
                        </Col>
                        <Col>
                        <input type="text" style={{ position: 'absolute', 
                            width:"500px", height:"25px"}} onChange={this.three}></input> 
                        </Col>
                    </Row>
                    <br />
                    <Row>
                        <Col md={3}>
                            <p>updated Text:</p>
                        </Col>
                        <Col>
                        <input type="text" style={{ position: 'absolute', 
                        width:"500px", height:"50px"}} onChange={this.four}></input> 
                        </Col>
                    </Row>
                    <br />
                    <ButtonGroup>
                    <Button outline color='danger' onClick={ () => this.hideUpdate()} variant="primary" style={{marginLeft: '300px'}}> Cancel Update</Button>
                    <Button outline color='success'  onClick={ () => this.sendNewPost()} variant="primary"> Update!</Button>
                    </ButtonGroup>
                    {/* <Row>
                        <Col>
                        <button style={{position:"absolute", left:"400px"}} onClick={ () => this.hideUpdate()} variant="primary"> Cancel Update</button>
                        </Col>
                        <Col>
                        <button style={{position:"absolute", left:"100px"}} onClick={ () => this.sendNewPost()} variant="primary"> Update!</button>
                        </Col>
                    </Row> */}
                   </div>


            <p> {this.state.txt}</p>
                </Container>
            </div>
        )
    }
}

export default Comments;